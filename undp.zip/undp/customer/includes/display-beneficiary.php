<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">View Beneficiaries</h4>
                  <p class="card-category">View Added Beneficiaries</p>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <form action="../../includes/functions/delete-beneficiary.php">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>Id</th>
                        <th>Name</th>
                        <th>Beneficiary Account No</th>
                        <th>status</th>
                      </thead>
                      <tbody>
                        <?php
include '../../_inc/dbconn.php';
$sender_id=$_SESSION["login_id"];
$sql="SELECT * FROM beneficiary1 WHERE sender_id='$sender_id'";
$result=  mysql_query($sql) or die(mysql_error());

                        while($rws=  mysql_fetch_array($result)){
                            echo "<tr><td><input type='radio' name='customer_id' value=".$rws[0];
                            echo ' checked';
                            echo " /></td>";
                            echo "<td>".$rws[4]."</td>";
                            echo "<td>".$rws[3]."</td>";
                            echo "<td>".$rws[5]."</td>";
                           
                            echo "</tr>";
                        } ?>
                    
                        
                      </tbody>
                    </table>
                    <button type="submit" name="submit_id" class="btn btn-primary pull-right">Delete Beneficiary</button>
                  </form>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>