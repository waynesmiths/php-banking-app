<?php
                    include '../../_inc/dbconn.php';
        $sender_id=$_SESSION["login_id"];
        
        
        $sql="SELECT * FROM beneficiary1 WHERE sender_id='$sender_id' AND status='ACTIVE'";
        $result=  mysql_query($sql);
        $rws=mysql_fetch_array($result);
        $s_id=$rws[1];              
        ?>
<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Send Money</h4>
                  <p class="card-category">Send Money to Beneficiary</p>
                </div>
                <div class="card-body">
                  <?php       
        if($sender_id==$s_id)    
        {
        echo "<form action='../../includes/functions/transfer-process.php' method='POST'>";
                echo "<div class='row'>";    
                  echo "<div class='col-md-5'>";    
                    echo "<div class='form-group'>";    
                      
            echo "<select name='transfer' class='form-control'>";           
                        $sql1="SELECT * FROM beneficiary1 WHERE sender_id='$sender_id' AND status='ACTIVE'";
        $result=  mysql_query($sql);
                
        while($rws=mysql_fetch_array($result)) {
        echo "<option disabled selected hidden>Select Beneficiary</option>";   
        echo "<option value='$rws[3]'>$rws[4]</option>";
        }
      
        echo "</select>";
                          
                    echo "</div>";      
                        
                      echo "</div>"; 
                       echo "<div class='col-md-6'>"; 
                       echo "<div class='form-group'>"; 
                          
                        echo "<input type='number' name='t_val' placeholder='Amount' class='form-control' required='' min='1'  max='1000000'>";  
                        
                        
                        echo "</div>";
                        echo "</div>";
                    echo "</div>";                    
                    
                    echo "</div>";
                     echo "<button type='submit' name='submitBtn' class='btn btn-primary pull-right'>Send Money</button>"; 
                   echo "<div class='clearfix'>";
                   echo "</div>";
                  echo "</div>";
                  echo "</form>";
                          }
        else{
            echo "<br><br><div class='head'><h3>No Benefeciary Added with your account.</h3></div>";
        }
                  echo "</div>";
                  echo "</div>";
                  echo "</div>";
                  echo "</div>";
                  echo "</div>";
                  ?>
            
          