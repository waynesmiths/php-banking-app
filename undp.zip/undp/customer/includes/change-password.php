<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Change Password</h4>
                  <p class="card-category">Change Dashboard Password </p>
                </div>
                <div class="card-body">
                  <form action="" method="post">
                    <input type="text" name='sender_acc' value='<?php echo $account_no;?>' readonly="" hidden=''>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Enter Old Password</label>
                          <input type="password" name="old_password" required="" class="form-control" >
                        </div>
                      </div>
                      
                      
                    </div>
                    
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Enter New Password</label>
                          <input type="password" name="new_password" class="form-control">
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Enter Password Again</label>
                          <input type="password" name="again_password" class="form-control">
                        </div>
                      </div>
                    </div>
                    
                    </div>
                    <button type="submit" name="change_password" class="btn btn-primary pull-right">Change Password</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      <?php
            $change=$_SESSION['login_id'];
            if(isset($_REQUEST['change_password'])){
            $sql="SELECT * FROM customer WHERE acc_no='$change'";
            $result=mysql_query($sql);
            $rws=  mysql_fetch_array($result);
            
            $salt="@g26jQsG&nh*&#8v";
            $old=  sha1($_REQUEST['old_password'].$salt);
            $new=  sha1($_REQUEST['new_password'].$salt);
            $again=sha1($_REQUEST['again_password'].$salt);
            
            if($rws[10]==$old && $new==$again){
                $sql1="UPDATE customer SET password='$new' WHERE acc_no='$change'";
                mysql_query($sql1) or die(mysql_error());
                header('location:index.php');
            }
            else{
                
                header('location:change-password.php');
            }
            }
            ?>
