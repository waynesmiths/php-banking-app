<div class="logo">
        <a href="index.php" class="simple-text logo-normal"><img src="../assets/img/sidebar-1.jpg">
          IOFC BANK
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./user.php">
              <i class="material-icons">person</i>
              <p>User Profile</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./mini-statement.php">
              <i class="material-icons">content_paste</i>
              <p>Mini Statement</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./full-statement.php">
              <i class="material-icons">book</i>
              <p>Full Statement</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./add-beneficiary.php">
              <i class="material-icons">add</i>
              <p>Add Beneficiary</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./display-beneficiary.php">
              <i class="material-icons">location_ons</i>
              <p>Display Beneficiaries</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./transfer.php">
              <i class="material-icons">send</i>
              <p>Local Transfer</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./internationaltransfer.php">
              <i class="material-icons">send</i>
              <p>International Transfer</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./change-password.php">
              <i class="material-icons">security</i>
              <p>Change Password</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="../../includes/functions/logout.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>

          
        </ul>
      </div>
    </div>
    <div class="main-panel">