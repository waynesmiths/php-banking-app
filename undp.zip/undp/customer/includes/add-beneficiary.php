<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Beneficiary</h4>
                  <p class="card-category">Input Beneficiary Account Details</p>
                </div>
                <div class="card-body">
                  <form action="../../includes/functions/add-beneficiary-process.php" method="post">
                    <input type="text" name='sender_acc' value='<?php echo $account_no;?>' readonly="" hidden=''>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Beneficiary Full Name</label>
                          <input type="text" name="name" required="" class="form-control" >
                        </div>
                      </div>
                      
                      
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Account Number</label>
                          <input type="number" name="account_no" required="" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          
                          <select name='branch_select' class="form-control" required>
                        
                        <option value='SAVINGS'>Savings</option>
                        <option value='CURRENT'>Current</option>
                        
                        
                        </select>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Token Code</label>
                          <input type="password" name='ifsc_code' class="form-control">
                        </div>
                      </div>
                    </div>
                    
                    </div>
                    <button type="submit" name="submitBtn" class="btn btn-primary pull-right">Add Beneficiary</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>