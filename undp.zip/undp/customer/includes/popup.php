<div class="fixed-plugin">
    <div class="dropdown show-dropdown">
      <a href="#" data-toggle="dropdown">
        <i class="fa fa-cog fa-2x"> </i>
      </a>
      <ul class="dropdown-menu">
        
        
        <li class="button-container">
          <a href="transfer.php" class="btn btn-primary btn-block">Local Transfer</a>
        </li>
        <li class="button-container">
          <a href="internationaltransfer.php" class="btn btn-primary btn-block">International Transfer</a>
        </li>
        <li class="button-container">
          <a href="full-statement.php" class="btn btn-default btn-block">
            View Statement of Account
          </a>
        </li>
        
      </ul>
    </div>
  </div>