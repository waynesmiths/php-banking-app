<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Simple Table</h4>
                  <p class="card-category"> Here is a subtitle for this table</p>
                </div>
                
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-primary">
                        <th>Id</th>
                        <th>Transaction Date</th>
                        <th>Narration</th>
                        <th>Credit</th>
                        <th>Debit</th>
                        <th>Balance Amount</th>
                      </thead>
                      <tbody>
                        <?php    include '../../_inc/dbconn.php';
                    if(isset($_REQUEST['summary_date'])) {
                         $date1=$_REQUEST['date1'];
                         $date2=$_REQUEST['date2'];
$sender_id=$_SESSION["login_id"];
$sql="SELECT * FROM passbook".$sender_id." WHERE transactiondate BETWEEN '$date1' AND '$date2'";
$result=  mysql_query($sql) or die(mysql_error());
                        
                        while($rws=  mysql_fetch_array($result)){
                            echo "<tr>";
                            echo "<td>".$rws[0]."</td>";
                            echo "<td>".$rws[1]."</td>";
                            echo "<td>".$rws[8]."</td>";
                            echo "<td>$ ".$rws[5]."</td>";
                            echo "<td>$ ".$rws[6]."</td>";
                            echo "<td class='text-primary'>$ ".$rws[7]."</td>";
                            echo "</tr>";
                          }
                        } ?>
                    
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>