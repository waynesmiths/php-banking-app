<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">International Transfer</h4>
                  <p class="card-category">Please fill the form below very carefully, your account might be temporarily blocked or suspended if the fields in the form are incorrect.</p>
                </div>
                <div class="card-body">
                  <form action="../../includes/functions/addinternationaltransfer.php" method="post">
                    <input type="text" name='sender_acc' value='<?php echo $account_no;?>' readonly="" hidden=''>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Full Name</label>
                          <input type="text" name="name" required="" class="form-control" >
                        </div>
                      </div>
                      
                      
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Account Number</label>
                          <input type="number" name="account_no" required="" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          
                          <select name='account_type' class="form-control" required>
                        
                        <option value='SAVINGS'>Savings</option>
                        <option value='CURRENT'>Current</option>
                        <option value='CHECKING'>Checking</option>
                        <option value='FIXED'>Fixed</option>
                        
                        
                        </select>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Amount</label>
                          <input type="number" name="amount" required="" class="form-control" min="1000" max="50000">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile Bank Username</label>
                          <input type="text" name="username" required="" class="form-control">
                        
                      </div>
                      </div>
                    </div>
                   
                      
                      <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile Bank Password</label>
                          <input type="password" name='password' class="form-control" required="">
                        </div>
                      </div>
                  
                    <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Transfer Pin</label>
                          <input type="text" name='swift_code' class="form-control" required="">
                        </div>
                      </div>
                      </div>
                 
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Description</label>
                          <textarea class="form-control" maxlength="50" name="description" required=""></textarea>
                        </div>
                      </div>
                    </div>
                    
                    </div>
                    <button type="submit" name="submitBtn" class="btn btn-primary pull-right">Transfer Fund</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>