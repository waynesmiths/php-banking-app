<footer class="footer">
        <div class="container-fluid"> 
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script> Copyright, UNDP. <i class="material-icons"></i>All Rights Reserved
          </div>
        </div>

      </footer>