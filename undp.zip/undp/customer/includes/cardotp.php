<div class="content" style="display:none; background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;" id="myDiv" class="animate-bottom">
  
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">OTP</h4>
                  <p class="card-category">We have sent you an OTP key</p>
                </div>
                <div class="card-body">
                  <form action="" method="post" >

                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">One Time Password</label>
                          <input type="text" name="otp" required="" class="form-control" >
                        </div>
                      </div>
                      
                      
                    </div>
                    </div>
                    <button type="submit" name="submitBtn1" class="btn btn-primary pull-right">Complete Transaction</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
