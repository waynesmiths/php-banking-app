<?php    include '../../_inc/dbconn.php';
$sender_id=$_SESSION["login_id"];
$sql="SELECT * FROM `passbook".$sender_id."` ORDER BY `transactionid` DESC LIMIT 5";
$result=  mysql_query($sql) or die(mysql_error()); ?>
<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Recent Transaction</h4>
                  <p class="card-category">Reccent transaction history</p>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-primary">
                       
                        <th>Transaction Date</th>
                        <th>Narration</th>
                        <th>Credit</th>
                        <th>Debit</th>
                        <th>Balance Amount</th>
                      </thead>
                      <tbody>
                        <?php
                        while($rws=  mysql_fetch_array($result)){
                            echo "<tr>";
                            echo "<td>".$rws[1]."</td>";
                            echo "<td>".$rws[8]."</td>";
                            echo "<td>$ ".$rws[5]."</td>";
                            echo "<td>$ ".$rws[6]."</td>";
                            echo "<td class='text-primary'>$ ".$rws[7]."</td>";
                            echo "</tr>";
                        } ?>
                    
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>