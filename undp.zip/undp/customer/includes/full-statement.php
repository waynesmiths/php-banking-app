<div class="content" style="background-image: url(../assets/img/bg.png); background-repeat: no-repeat; background-size: 100%; background-position:center;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-8">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Account Statement</h4>
                  <p class="card-category">Check Full Account Statement by Date</p>
                </div>
                <div class="card-body">
                  <form action="statement-date.php" method="post">
                    
                    
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                        
                          <input type="date" name="date1"required="" class="form-control">
                        </div>
                      </div>
                      <p>to</p>
                      <div class="col-md-6">
                        <div class="form-group">
                          
                          <input type="date" name="date2" required="" class="form-control">
                        </div>
                      </div>
                    </div>
                    
                    <button type="submit" name="summary_date" class="btn btn-primary pull-right">View Account Statement</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>