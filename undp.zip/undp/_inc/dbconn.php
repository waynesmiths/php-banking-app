<?php
$serverName="localhost";
$dbusername="undpsecu_bank";
$dbpassword="G;y;3OT-cjJ0";
$dbname="undpsecu_bank";
mysql_connect($serverName,$dbusername,$dbpassword)/* or die('the website is down for maintainance')*/;
mysql_select_db($dbname) or die(mysql_error());
?>