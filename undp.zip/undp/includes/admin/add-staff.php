<div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Add Staff</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form class="form-horizontal" action="../includes/admin/add-staff-process.php" method="post">
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Full Name</label>

                                    <div class="col-lg-10"><input type="text" name='staff_name' placeholder="Full Name" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Gender</label>

                                    <div class="col-lg-10">M<input type="radio" name="staff_gender" value="M" checked/>
                        F<input type="radio" name="staff_gender" value="F" /></div>
                                </div>
    
                                <div class="form-group"><label class="col-lg-2 control-label">Date of Birth</label>

                                    <div class="col-lg-10"><input type="date" name='staff_dob' placeholder="Date of Birth" class="form-control" required=""></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Relationship</label>

                                    <div class="col-lg-10"><select name='staff_status' class="form-control" required>
                            <option>Single</option>            
                            <option>Married</option> 
                            <option>Divorced</option> 
                        </select></div>
                                </div>

                                <div class="form-group"><label class="col-lg-2 control-label">Department</label>

                                    <div class="col-lg-10"><select name='staff_dept' class="form-control" required>
                            <option>Accounting</option>
                            <option>Developer</option>
                        
                        
                        </select></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Date of Join</label>

                                    <div class="col-lg-10"><input type="date" name='staff_doj' placeholder="Date of Birth" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Address</label>

                                    <div class="col-lg-10"><input type="text" name='staff_address' placeholder="Address" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Phone</label>

                                    <div class="col-lg-10"><input type="Number" name='staff_mobile' placeholder="Mobile Number" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Email Address</label>

                                    <div class="col-lg-10"><input type="email" name='staff_email' placeholder="Email Address" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Password</label>

                                    <div class="col-lg-10"><input type="password" name='staff_pwd' placeholder="Password" class="form-control" required=""></div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-sm btn-white" type="submit" name="add_staff">Add Staff</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>