<div class="ibox-content">

                            <form method="post" action="" class="form-horizontal">

                                    <div class="hr-line-dashed"></div>
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Enter Old Password</label>

                                    <div class="col-sm-10 col-md-6"><input type="password"  class="form-control" name="old_password"></div>


                            </div>

                            
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Enter New Password</label>

                                    <div class="col-sm-10 col-md-6" ><input type="password" class="form-control" name="new_password"></div>


                            </div>

                            
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Enter Password Again</label>

                                    <div class="col-sm-10 col-md-6"><input type="password" class="form-control" name="again_password"></div>


                            </div>
                            <div class="col-md-6">

                               <button type="submit" class="btn btn-primary block full-width m-b col-md-6" name="change_password">Change Password </button> 
                            </div>
                            
                        </form>
                    </div>