<div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Add Customer</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form class="form-horizontal" action="../includes/admin/add-customer-process.php" method="post" enctype="multipart/form-data">
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Full Name</label>

                                    <div class="col-lg-10"><input type="text" name='customer_name' placeholder="Full Name" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Gender</label>

                                    <div class="col-lg-10">M<input type="radio" name="customer_gender" value="M" checked/>
                        F<input type="radio" name="customer_gender" value="F" /></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Account Number</label>

                                    <div class="col-lg-10"><input type="Number" name='account_no' placeholder="Account Number" class="form-control" required="" min="1" maxlength="11"></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Date of Birth</label>

                                    <div class="col-lg-10"><input type="date" name='customer_dob' placeholder="Date of Birth" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Next of Kin</label>

                                    <div class="col-lg-10"><input type="text" name='customer_nominee' placeholder="next of kin full name" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Branch</label>

                                    <div class="col-lg-10"><select name='branch' class="form-control" required>
                            <option disabled selected hidden>Select Branch</option>
                            <option>WASHINGTON</option>
                            <option>KOLKATA</option>
                            <option>DELHI</option>
                            <option>BANGALORE</option>
                        
                        
                        </select></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Account Type</label>

                                    <div class="col-lg-10"><select name='customer_account' class="form-control" required>
                        <option value='' disabled selected hidden>Select Account Type</option>
                        <option value='SAVINGS'>Savings</option>
                        <option value='CURRENT'>Current</option>
                        <option value='FIXED'>Fixed</option>
                        <option value='CHECKING'>Checking</option>
                        
                        
                        </select></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Minimum Deposit</label>

                                    <div class="col-lg-10"><input type="Number" name='initial' placeholder="Minimum Deposit" class="form-control" required="" min="1000" value="1000"></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Address</label>

                                    <div class="col-lg-10"><input type="text" name='customer_address' placeholder="Address" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Phone</label>

                                    <div class="col-lg-10"><input type="Number" name='customer_mobile' placeholder="Mobile Number" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Email Address</label>

                                    <div class="col-lg-10"><input type="email" name='customer_email' placeholder="Email Address" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Password</label>

                                    <div class="col-lg-10"><input type="password" name='customer_pwd' placeholder="Password" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Picture</label>

                                    <div class="col-lg-10"><input type="file" placeholder="Picture" class="form-control" name="file" id="fileToUpload"></div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-sm btn-white" type="submit" name="add_customer">Add Customer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>