<?php
include '../../_inc/dbconn.php';
                        $delete_id=  mysql_real_escape_string($_REQUEST['staff_id']);
                        if(isset($_REQUEST['submit2_id'])){
                            $sql_delete="DELETE FROM `staff` WHERE `id` = '$delete_id'";
                            mysql_query($sql_delete) or die(mysql_error());
                            header('location:../../admin/index.php');
                        }
                        ?>