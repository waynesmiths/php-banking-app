<div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Horizontal form</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form class="form-horizontal" action="../includes/admin/alter-customer.php" method="post">
                                <input type="hidden" name="current_id" value="<?php echo $id;?>"/>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Full Name</label>

                                    <div class="col-lg-10"><input type="text" name="edit_name" value="<?php echo $rws[2];?>" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Gender</label>

                                <div class="col-lg-10">M<input type="radio" name="edit_gender" value="M" <?php if($rws[3]=="M") echo "checked";?>/>F<input type="radio" name="edit_gender" value="F" <?php if($rws[3]=="F") echo "checked";?>/></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Date of Birth</label>

                                    <div class="col-lg-10"><input type="date" name="edit_dob" value="<?php echo $rws[4];?>" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Next of Kin</label>

                                    <div class="col-lg-10"><input type="text" name="edit_nominee" value="<?php echo $rws[5];?>" class="form-control" required=""></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Account Type</label>

                                    <div class="col-lg-10"><select name='edit_account' class="form-control" required>
                        
                        <option <?php if($rws[6]=="savings") echo "selected";?>>Savings</option>
                        <option <?php if($rws[6]=="current") echo "selected";?>>Current</option>
                        <option <?php if($rws[6]=="fixed") echo "selected";?>>Fixed</option>
                        <option <?php if($rws[6]=="checking") echo "selected";?>>Checking</option>
                        
                        
                        
                        
                        </select></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Address</label>

                                    <div class="col-lg-10"><input type="text" name='edit_address' value="<?php echo $rws[7];?>" class="form-control" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Phone</label>

                                    <div class="col-lg-10"><input type="Number" name="edit_mobile" value="<?php echo $rws[8];?>" class="form-control" required=""></div>
                                </div>
                            
                                
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-sm btn-white" type="submit" name="alter_customer">Update Customer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>