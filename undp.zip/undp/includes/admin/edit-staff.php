<div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Edit Staff</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form class="form-horizontal" action="../includes/admin/edit-staff-process.php" method="post">
                                <input type="hidden" name="current_id" value="<?php echo $id;?>"/>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Full Name</label>

                                    <div class="col-lg-10"><input type="text" name='edit_name' placeholder="Full Name" class="form-control" value="<?php echo $rws[1];?>" required="">
                                    </div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Gender</label>

                                    <div class="col-lg-10">
                                        M<input type="radio" name="edit_gender" value="M" <?php if($rws[10]=="M") echo "checked";?>/>
                        F<input type="radio" name="edit_gender" value="F" <?php if($rws[10]=="F") echo "checked";?>/></div>
                                </div>
    
                                <div class="form-group"><label class="col-lg-2 control-label">Date of Birth</label>

                                    <div class="col-lg-10"><input type="date" value="<?php echo $rws[2];?>" name='edit_dob' placeholder="Date of Birth" class="form-control" required=""></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Relationship</label>

                                    <div class="col-lg-10"><select name='edit_status' class="form-control" required>
                            <option <?php if($rws[3]=="unmarried") echo "selected";?>>single</option>
                            <option <?php if($rws[3]=="married") echo "selected";?>>married</option>
                            <option <?php if($rws[3]=="divorced") echo "selected";?>>divorced</option>
                        
                        
                        </select></div>
                                </div>

                                <div class="form-group"><label class="col-lg-2 control-label">Department</label>

                                    <div class="col-lg-10"><select name='edit_dept' class="form-control" required>
                            <option <?php if($rws[4]=="Accounting") echo "selected";?>>revenue</option>
                            <option <?php if($rws[4]=="developer") echo "selected";?>>developer</option>
                        
                        
                        </select></div>
                                </div>
                                
                                <div class="form-group"><label class="col-lg-2 control-label">Date of Join</label>

                                    <div class="col-lg-10"><input type="date" name='edit_doj' placeholder="Date of Birth" class="form-control" value="<?php echo $rws[5];?>" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Address</label>

                                    <div class="col-lg-10"><input type="text" name='edit_address' placeholder="Address" class="form-control" value="<?php echo $rws[6];?>" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Phone</label>

                                    <div class="col-lg-10"><input type="Number" name='edit_mobile' placeholder="Mobile Number" class="form-control" value="<?php echo $rws[7];?>" required=""></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Email Address</label>

                                    <div class="col-lg-10"><input type="email" name='edit_email' placeholder="Email Address" class="form-control" value="<?php echo $rws[8];?>" required=""></div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-sm btn-white" type="submit" name="alter">Update Staff</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>