
<?php
include '../../_inc/dbconn.php';
                        $delete_id=  mysql_real_escape_string($_REQUEST['customer_id']);
                        if(isset($_REQUEST['submit2_id'])){
                            $sql_delete="DELETE FROM `customer` WHERE `acc_no` = '$delete_id'";
                            $sql_drop="DROP TABLE passbook".$delete_id;
                            mysql_query($sql_delete) or die(mysql_error());
                            mysql_query($sql_drop) or die(mysql_error());
                            header('location:../../admin/delete-customer.php');
                        }
                        ?>