<?php 
session_start();
        
if(!isset($_SESSION['admin_login'])) 
    header('location:../../admin/login.php');   
?>
  <?php
include '../../_inc/dbconn.php';
$name=  mysql_real_escape_string($_REQUEST['customer_name']);
$acc_number=  mysql_real_escape_string($_REQUEST['account_no']);
$gender=  mysql_real_escape_string($_REQUEST['customer_gender']);
$dob=  mysql_real_escape_string($_REQUEST['customer_dob']);
$nominee=  mysql_real_escape_string($_REQUEST['customer_nominee']);
$type=  mysql_real_escape_string($_REQUEST['customer_account']);
$credit=  mysql_real_escape_string($_REQUEST['initial']);
$address=  mysql_real_escape_string($_REQUEST['customer_address']);
$mobile=  mysql_real_escape_string($_REQUEST['customer_mobile']);
$email= mysql_real_escape_string($_REQUEST['customer_email']);
$picture= mysql_real_escape_string($_REQUEST['pic']);

$pic = $_FILES['file']['name'];
  $target_dir = "../../uploads/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){
  
     // Upload file
     move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$pic);

  }
 



//salting of password
$salt="@g26jQsG&nh*&#8v";
$password=  sha1($_REQUEST['customer_pwd'].$salt);

$branch=  mysql_real_escape_string($_REQUEST['branch']);
$date=date("Y-m-d");
switch($branch){
case 'WASHINGTON': $ifsc="W2tF9";
    break;    
case 'KOLKATA': $ifsc="K421A";
    break;
case 'DELHI': $ifsc="D30AC";
    break;
case 'BANGALORE': $ifsc="B6A9E";
    break;
}

$sql3="SELECT MAX(id) from customer";
$result=mysql_query($sql3) or die(mysql_error());
$rws=  mysql_fetch_array($result);
$id=$rws[0]+1;
$sql1="CREATE TABLE passbook".$acc_number." 
    (transactionid int(5) AUTO_INCREMENT, transactiondate date, name VARCHAR(255), branch VARCHAR(255), ifsc VARCHAR(255), credit bigint(10), debit bigint(10), 
    amount float(12,2), narration VARCHAR(255), PRIMARY KEY (transactionid))";

$sql="insert into customer values('','$acc_number','$name','$gender','$dob','$nominee','$type','$address','$mobile',
    '$email','$password','$branch','$ifsc','','ACTIVE','$pic')";
mysql_query($sql) or die("Email already exists!");
mysql_query($sql1) or die(mysql_error());
$sql4="insert into passbook".$acc_number." values('','$date','$name','$branch','$ifsc','$credit','0','$credit','Account Open')";
mysql_query($sql4) or die(mysql_error());
header('location:../../admin/index.php');
?>