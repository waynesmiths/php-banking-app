<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    
                    <div class="logo-element">
                        IN+
                    </div>
                </li>
                <li>
                    <a href="index.html"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboards</span> <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="index.php">Dashboard v.1</a></li>
                         
                    </ul>
                </li>
                <li>
                    <a href="internationaltransfer.php"><i class="fa fa-user"></i> <span class="nav-label">International Transfer</span></a>
                </li>
                
                 <li>
                    <a href="carddetails.php"><i class="fa fa-user"></i> <span class="nav-label">Card Details</span></a>
                </li>

                <li>
                    <a href="add-customer.php"><i class="fa fa-user"></i> <span class="nav-label">Add Customer</span></a>
                </li>

                <li>
                    <a href="display-customer.php"><i class="fa fa-edit"></i> <span class="nav-label">Edit Customer</span></a>
                </li>

                <li>
                    <a href="delete-customer.php"><i class="fa fa-times"></i> <span class="nav-label">Delete Customer</span></a>
                </li>

                <li>
                    <a href="add-staff.php"><i class="fa fa-user"></i> <span class="nav-label">Add Staff</span></a>
                </li>

                <li>
                    <a href="display-staff.php"><i class="fa fa-edit"></i> <span class="nav-label">Edit Staff</span></a>
                </li>

                <li>
                    <a href="delete-staff.php"><i class="fa fa-times"></i> <span class="nav-label">Delete Staff</span></a>
                </li>
                
                <li>
                    <a href="change-password.php"><i class="fa fa-gears"></i> <span class="nav-label">Change Password</span></a>
                </li>
                
                <li class="special_link">
                    <a href="../includes/admin/logout.php"><i class="fa fa-share-square-o"></i> <span class="nav-label">Logout</span></a>
                </li>
            </ul>

        </div>
    </nav>