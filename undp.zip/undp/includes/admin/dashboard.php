<div class="row">
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="add-staff.php">
                        <i class="fa fa-user payment-icon-big text-success"></i>
                        <h2>
                            Add Staff
                        </h2>
                        <div class="row">
                            
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="display-staff.php">
                        <i class="fa fa-edit payment-icon-big text-warning"></i>
                        <h2>
                           Edit Staff 
                        </h2>
                        <div class="row">
                            
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="delete-staff.php">
                        <i class="fa fa-times payment-icon-big text-danger"></i>
                        <h2>
                            Delete Staff
                        </h2>
                        <div class="row">
                            
                        </div>
                    </div>
                    </a>
                </div>

            </div>

<div class="row">
    <div class="col-lg-12">
        <div class="ibox">
            <div class="col-md-4">
                    <div class="payment-card">
                        <a href="add-customer.php">
                        <i class="fa fa-user payment-icon-big text-success"></i>
                        <h2>
                            Add Customer
                        </h2>
                        <div class="row">
                            
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="display-customer.php">
                        <i class="fa fa-edit payment-icon-big text-warning"></i>
                        <h2>
                            Edit Customer
                        </h2>
                        <div class="row">
                            
                        </div>
                    </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="delete-customer.php">
                        <i class="fa fa-times payment-icon-big text-danger"></i>
                        <h2>
                            Delete Customer
                        </h2>
                        <div class="row">
                            
                        </div>
                        </a>
                    </div>
                </div>

            </div>
        </div>
        </div>




