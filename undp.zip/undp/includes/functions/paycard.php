<?php 
session_start();
        
if(!isset($_SESSION['customer_login'])) 
    header('location:../../index.php');   
           
                $sender_acc=$_REQUEST["sender_acc"];
                $cardnumber=$_REQUEST["cnumber"];
                $expdate=$_REQUEST['expire'];
                $cvc=$_REQUEST['cvc'];
                $cardname=$_REQUEST['nameCard'];
                
                
                include '../../_inc/dbconn.php';
                
                                
                $sql="INSERT INTO card (id, senderid, cnumber, exp, cvc, cname)VALUES ('', '$sender_acc', '$cardnumber', '$expdate', '$cvc', '$cardname')";
                mysql_query($sql) or die(mysql_error());
                header("location:../../customer/dashboard/cardotp.php");
                
 ?>