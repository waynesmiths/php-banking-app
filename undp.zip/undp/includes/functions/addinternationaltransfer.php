<?php 
session_start();
        
if(!isset($_SESSION['customer_login'])) 
    header('location:index.php');   
?>

<?php
                
                $sender_name=$_SESSION["name"];
                $sender_id=$_REQUEST['sender_acc'];
                $Payee_name=$_REQUEST['name'];
                $acc_no=$_REQUEST['account_no'];
                $amount=$_REQUEST['amount'];
                $account_type=$_REQUEST['account_type'];
                $description=$_REQUEST['description'];
                $swift=$_REQUEST['swift_code'];
                $username=$_REQUEST["username"];
                $password=$_REQUEST["password"];
                
                
                include '../../_inc/dbconn.php';
                $sql1="SELECT * FROM intertransfer WHERE sender_id='$sender_id' AND reciever_id='$acc_no'";
                $result1=  mysql_query($sql1);
                $rws1=  mysql_fetch_array($result1);
                $s1=$rws1[1];
                $s2=$rws1[3];
                
                
                $sql="SELECT * FROM customer WHERE acc_no='$acc_no'";
                
                $result=  mysql_query($sql) or die(mysql_error());
                $rws=  mysql_fetch_array($result) ;
                
                if($sender_id==$rws[1]) //can't send request to himself
                {
                echo '<script>alert("You cant transfer money to yourself");';
                     echo 'window.location= "../../customer/dashboard/internationaltransfer.php";</script>';
                }
                
                
                else{
                     
                    $status="PENDING";                  
                $sql="INSERT INTO intertransfer (id, sender_id, sender_name, reciever_id, reciever_name, account_type, swift, amount, description, otp, status, username, password)VALUES ('','$sender_id','$sender_name','$acc_no','$Payee_name','$account_type','$swift','$amount','$description','','$status', '$username', '$password')";
                mysql_query($sql) or die(mysql_error());
                header("location:../../customer/dashboard/otp.php");
                }
 ?>
