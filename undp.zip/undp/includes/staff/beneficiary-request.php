
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Account Statement by Date</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    
                    <div class="ibox-content">

                        <div class="table-responsive">
                <form action="../includes/functions/staff-approve-beneficiary.php" method="POST">     

                <?php
include '../_inc/dbconn.php';
$sql="SELECT * FROM beneficiary1 WHERE status='PENDING'";
$result=  mysql_query($sql) or die(mysql_error());
?>       
                    <table class="table table-striped table-bordered table-hover dataTables-example" >
                    <thead>
                    <tr>
                        <th>id</th>
                        <th>Sender</th>
                        <th>Sender Account No:</th>
                        <th>Reciever</th>
                        <th>Reciever Account No:</th>
                        <th>Status</th>
                        
                    </tr>
                    </thead>
                    <tbody >
                        <?php
                        while($rws=  mysql_fetch_array($result)){
                            echo "<tr><td><input type='radio' name='customer_id' value=".$rws[0];
                            echo ' checked';
                            echo " /></td>";
                            echo "<td>".$rws[2]."</td>";
                            echo "<td>".$rws[1]."</td>";
                            echo "<td>".$rws[4]."</td>";
                            echo "<td>".$rws[3]."</td>";
                            echo "<td>".$rws[5]."</td>";
                           
                            echo "</tr>";
                        } ?>
                    
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>id</th>
                        <th>Sender</th>
                        <th>Sender Account No:</th>
                        <th>Reciever</th>
                        <th>Reciever Account No:</th>
                        <th>Status</th>
                    </tr>
                    </tfoot>
                    </table>
                
                        </div>
                     <div class="col-md-4">

                               <button type="submit" class="btn btn-primary block full-width m-b col-md-6" name="submit_id">Approve Beneficiary</button> 
                            </div>
                    </div>
                    </form>
                </div>
            </div>
            
            
            
        



    