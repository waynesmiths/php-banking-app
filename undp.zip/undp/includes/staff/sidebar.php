<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    
                    <div class="logo-element">
                        IN+
                    </div>
                </li>
                <li>
                    <a href="index.html"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboards</span> <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="index.php">Dashboard v.1</a></li>
                         
                    </ul>
                </li>

                <li>
                    <a href="beneficiary-request.php"><i class="fa fa-user"></i> <span class="nav-label">Beneficiary Request</span></a>
                </li>
                
                <li>
                    <a href="change-password.php"><i class="fa fa-gears"></i> <span class="nav-label">Change Password</span></a>
                </li>
                
                <li class="special_link">
                    <a href="../includes/staff/logout.php"><i class="fa fa-share-square-o"></i> <span class="nav-label">Logout</span></a>
                </li>
            </ul>

        </div>
    </nav>