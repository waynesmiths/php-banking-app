<div class="row">
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="">
                        <i class="fa fa-user payment-icon-big text-success"></i>
                        <h2>
                            <?php echo $_SESSION['name1']?>
                        </h2>
                        <div class="row">
                            <div class="col-sm-6">
                                <small>
                                    <strong>Date  of Join</strong> <?php echo $doj;?>
                                </small>
                            </div>
                            <div class="col-sm-6 text-right">
                                <small>
                                    <strong><?php echo $department;?></strong>
                                </small>
                            </div>
                            
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="payment-card">
                        <a href="">
                        <i class="fa fa-cc-mastercard payment-icon-big text-warning"></i>
                        <h2>
                            **** **** **** 7002
                        </h2>
                        <div class="row">
                         <h2>
                            Approve ATM
                        </h2>   
                        </div>
                        </a>
                    </div>
                </div>
                

            </div>





