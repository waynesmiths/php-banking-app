<div class="footer">
            
            <div>
                <strong>Copyright</strong> Bank &copy; 2019
            </div>
        </div>