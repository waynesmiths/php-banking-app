<?php
                    include '../_inc/dbconn.php';
        $sender_id=$_SESSION["login_id"];
        
        
        $sql="SELECT * FROM beneficiary1 WHERE sender_id='$sender_id' AND status='ACTIVE'";
        $result=  mysql_query($sql);
        $rws=mysql_fetch_array($result);
        $s_id=$rws[1];              
        ?>
<div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Transfer Fund</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                             <?php       
        if($sender_id==$s_id)    
        {
        echo "<form action='../includes/functions/transfer-process.php' method='POST' class='form-horizontal'>";
        
        echo "<div class='form-group'>";
        
        echo "<div class='col-lg-10'>" ;
        echo "<select name='transfer' class='form-control'>" ; 
        
        $sql1="SELECT * FROM beneficiary1 WHERE sender_id='$sender_id' AND status='ACTIVE'";
        $result=  mysql_query($sql);
                
        while($rws=mysql_fetch_array($result)) {
            
        echo "<option value='$rws[3]'>$rws[4]</option>";
        }
      
        echo "</select>";
        echo "</div>";
        echo "</div>";
        echo "<div class='form-group'>";
        echo "<label class='col-lg-2 control-label'>Amount</label>";

        echo "<div class='col-lg-10'>";
        echo "<input type='number' name='t_val' placeholder='Amount' class='form-control' required='' min='1'  max='10000'>";
        echo "</div>";
        echo "</div>";                       

        echo "<div class='form-group'>";
        echo "<div class='col-lg-offset-2 col-lg-10'>";
        echo "<button class='btn btn-sm btn-white' type='submit' name='submitBtn'>Transfer Fund</button>";
        echo "</div>";
        echo "</div>";
        echo "</form>";
        }
        else{
            echo "<br><br><div class='head'><h3>No Benefeciary Added with your account.</h3></div>";
        }
        ?>                        
                                
                                
                        </div>
                    </div>
                </div>
            </div>