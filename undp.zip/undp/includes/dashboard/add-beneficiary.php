<div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Add Beneficiary</h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">
                            <form class="form-horizontal" action="../includes/functions/add-beneficiary-process.php" method="post">
                                <input type="text" name='sender_acc' value='<?php echo $account_no;?>' readonly="" hidden=''>
                                <div class="form-group"><label class="col-lg-2 control-label">Beneficiary Full Name</label>

                                    <div class="col-lg-10"><input type="text" name='name' placeholder="Full Name" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Beneficiary Account Number</label>

                                    <div class="col-lg-10"><input type="Number" name='account_no' placeholder="Account Number" class="form-control" required="" min="0" maxlength="11"></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Beneficiary Account Type</label>

                                    <div class="col-lg-10"><select name='branch_select' class="form-control" required>
                        
                        <option value='SAVINGS'>Savings</option>
                        <option value='CURRENT'>Current</option>
                        
                        
                        </select></div>
                                </div>
                                <div class="form-group"><label class="col-lg-2 control-label">Token Code</label>

                                    <div class="col-lg-10"><input type="password" name='ifsc_code' placeholder="Token Code" class="form-control" required=""></div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-sm btn-white" type="submit" name="submitBtn">Add Beneficiary</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>