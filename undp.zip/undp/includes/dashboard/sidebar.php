<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <h1><a href="index.php">RENAPROV CAMEROUN</a></h1>
                    <div class="dropdown profile-element"> <span>
                            <img alt="image" class="img-circle" src="../img/a4.jpg" />
                             </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $_SESSION['name']?></strong>
                             </span> <span class="text-muted text-xs block fa fa-gear">Settinsgs <b class="caret"></b></span> </span> </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="personal-details.php">Profile</a></li>
                            
                            <li><a href="change-password.php">Chage password</a></li>
                            <li class="divider"></li>
                            <li><a href="../includes/functions/logout.php">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        IN+
                    </div>
                </li>
                <li>
                    <a href="index.html"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="index.php">Dashboard v.1</a></li>
                         
                    </ul>
                </li>
                
                <li>
                    <a href="#"><i class="fa fa-bar-chart-o"></i> <span class="nav-label">Transaction History</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="mini-statement.php">Latest Transaction</a></li>
                        <li><a href="statement.php">Account  Statement</a></li>
                        
                    </ul>
                </li>
                <li>
                    <a href="mailbox.html"><i class="fa fa-money"></i> <span class="nav-label">Fund Transfer </span><span class="label label-warning pull-right">$</span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="add-beneficiary.php">Add Beneficiary</a></li>
                        <li><a href="display-beneficiary.php">View Added Beneficiary</a></li>
                        <li><a href="transfer.php">Transfer Fund</a></li>
                    </ul>
                </li>
                
                <li>
                    <a href="#"><i class="fa fa-user"></i> <span class="nav-label">Profile</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="personal-details.php">Personal Details</a></li>
                        <li><a href="change-password.php">Change Password</a></li>
                        
                    </ul>
                </li>
                
                
                
                <li class="special_link">
                    <a href="../includes/functions/logout.php"><i class="fa fa-share-square-o"></i> <span class="nav-label">Logout</span></a>
                </li>
            </ul>

        </div>
    </nav>