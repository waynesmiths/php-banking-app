<div class="wrapper wrapper-content">
            <div class="row animated fadeInRight">
                <div class="col-md-4">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Profile Detail</h5>
                        </div>
                        <div>
                            <div class="ibox-content no-padding border-left-right">
                                <img alt="image" class="img-responsive" src="img/profile_big.jpg">
                            </div>
                            <div class="ibox-content profile-content">
                                <h4><strong><?php echo $name;?></strong></h4>
                                
                                
                            </div>
                    </div>
                </div>
                    </div>
                <div class="col-md-8">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5></h5>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-wrench"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-user">
                                    <li><a href="#">Config option 1</a>
                                    </li>
                                    <li><a href="#">Config option 2</a>
                                    </li>
                                </ul>
                                <a class="close-link">
                                    <i class="fa fa-times"></i>
                                </a>
                            </div>
                        </div>
                        <div class="ibox-content">

                            <form method="get" class="form-horizontal">

                                    <div class="hr-line-dashed"></div>
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Full Name</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" value="<?php echo $name;?>" class="form-control" readonly=""></div>


                            </div>

                            
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Gender</label>

                                    <div class="col-sm-10 col-md-6" ><input type="text" class="form-control" value="<?php if($gender=='M') echo "Male"; else echo "Female";?>" readonly=""></div>


                            </div>

                            
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Phone</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $mobile;?>" readonly=""></div>


                            </div>

                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Email</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" value="<?php echo $email;?>" class="form-control" readonly=""></div>


                            </div>

                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Address</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $address;?>" readonly=""></div>


                            </div>

                            
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Account Number</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $account_no;?>" readonly=""></div>


                            </div>

                            
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Next of kin</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $nominee;?>" readonly=""></div>


                            </div>
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Branch</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $branch;?>" readonly=""></div>


                            </div>
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Token</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $branch_code;?>" readonly=""></div>


                            </div>
                            <div class="form-group has-success">
                                <label class="col-sm-2 col-md-4 control-label">Account Type</label>

                                    <div class="col-sm-10 col-md-6"><input type="text" class="form-control" value="<?php echo $acc_type;?>" readonly=""></div>


                            </div>
                        </form>



                        </div>
                    </div>

                </div>
            </div>
        </div>