<form action="statement-date.php" method="post">
<div class="form-group" id="data_2">
                                <label class="font-noraml">Start Date</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="date" class="form-control" value="08/09/2014" required="" name="date1">
                                </div>
                            </div>

                            <div class="form-group" id="data_3">
                                <label class="font-noraml">End Date</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span><input type="date" class="form-control" value="10/11/2013" required="" name="date2">
                                </div>
                            </div>
                             <button type="submit" class="btn btn-primary block full-width m-b" name="summary_date">View Account Statement </button>
</form>